function mathOperation(arg1, arg2, operation)
{
    switch(operation)
    {
        case plus:
            alert("Case 5: Сложение " + (plus(arg1, arg2)));
            break;

        case minus:
            alert("Case 5: Вычитание " + (minus(arg1, arg2)));
            break;
        
        case multiply:
            alert("Case 5: Умножение " + (multiply(arg1, arg2)));
            break;

        case divide:
            alert("Case 5: Деление " + (divide(arg1, arg2)));
            break;
    }
}

mathOperation(10, 20, plus);    //30
mathOperation(10, 20, minus);   //-10
mathOperation(10, 20, multiply);//200
mathOperation(10, 20, divide);  //0.5