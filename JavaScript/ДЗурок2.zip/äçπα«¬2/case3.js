let a3 = 20;
let b3 = 15;

if(a3 >= 0 & b3 >= 0)
{
    alert("Case 3 = " + (a3 - b3));
}
else if((a3 < 0 & b3 >= 0) || (a3 >= 0 & b3 < 0))
{
    alert("Case 3 = " + (a3 + b3));
}
else
{
    alert("Case 3 = " + (a3 * b3));
}