// Запрашиваем число
let inputValue = +prompt("Какую сумму вы хотите внести на счет? ");

// Проверяем на число и знак
while(isNaN(inputValue) || inputValue < 1)
{
    alert("Введено не число, или оно меньше нуля");
    inputValue = +prompt("Какую сумму вы хотите внести на счет? ");
}

// Конвертируем число в строку с помощью .ToString
let inputValueStr = inputValue.toString();

// Делим строку на массив символов с помощью split и разделителя ""
let intputValueArr = inputValueStr.split("");

// Определяем последний символ в массиве и присваивем его
// обьявленной переменной endChar
let endChar = intputValueArr[intputValueArr.length - 1];

// Обьявляем переменную для склонения слова "рубль"
let rubEnding = ""

// Обьявляем условие изменения склонения слова "рубль"
if(endChar == 0 || endChar >= 5 && endChar <= 9 )
{
    rubEnding = " рублей";
}
else if(endChar == 1)
{
    rubEnding = " рубль";
}
else
{
    rubEnding = " рубля";
}
// Выводим сообщение об успешной операции с вставкой вводимого числа и полученным
// склонением слова "рубль"
alert("Ваша сумма в " + inputValue + rubEnding + " успешно зачислена");