let value1 = 10;
let value2 = 15;

//сложение
function plus(num1, num2)
{
   return num1 + num2;
}
alert("Case 4: Сложение " + plus(value1, value2)); //25

//вычитание
function minus(num1, num2)
{
    return num1 - num2;
}
alert("Case 4: Вычитание " + minus(value1, value2)); //-5

//умножение
function multiply(num1, num2)
{
    return num1 * num2;
}
alert("Case 4: Умножение " + multiply(value1, value2)); //150

//деление
function divide(num1, num2)
{
    return num1 / num2;
}
alert("Case 4: Деление " + divide(value1, value2)); //~0.66